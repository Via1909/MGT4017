# BeautyLoop website prototype
Open `index.html` in a browser (internet only needed for Google Fonts).
css/styles.css = design · js/main.js = products, plans, bag, account, contact form · assets/ = logos from the wireframes.
Prototype: checkout and contact form are not connected to payments or email.
